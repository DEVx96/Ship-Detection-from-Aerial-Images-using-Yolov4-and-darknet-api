
ships - v1 boats
==============================

This dataset was exported via roboflow.ai on November 1, 2020 at 9:51 AM GMT

It includes 579 images.
Ships are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


